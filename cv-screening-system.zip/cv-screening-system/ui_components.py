"""
ui_components.py
Reusable UI building blocks: skill tag chips, score gauges, candidate
result cards, and empty states.
"""

import streamlit as st
import plotly.graph_objects as go
import json


# ---------- Style helpers ----------

def score_color(score: int) -> str:
    if score >= 75:
        return "#22c55e"   # green
    elif score >= 50:
        return "#eab308"   # yellow
    else:
        return "#ef4444"   # red


def recommendation_badge_style(recommendation: str):
    styles = {
        "Strongly Recommended": ("#22c55e", "#ecfdf5"),
        "Consider": ("#eab308", "#fefce8"),
        "Not Recommended": ("#ef4444", "#fef2f2"),
    }
    return styles.get(recommendation, ("#6b7280", "#f3f4f6"))


# ---------- Inject global CSS ----------

def inject_custom_css():
    st.markdown(
        """
        <style>
        .main { background-color: #f8fafc; }

        .candidate-card {
            background: white;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: 0 4px 14px rgba(0,0,0,0.06);
            border-left: 6px solid var(--score-color, #6b7280);
        }

        .skill-chip {
            display: inline-block;
            padding: 4px 14px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 600;
            margin: 3px 4px 3px 0;
        }
        .skill-chip-matched {
            background-color: #ecfdf5;
            color: #16a34a;
            border: 1px solid #86efac;
        }
        .skill-chip-missing {
            background-color: #fef2f2;
            color: #dc2626;
            border: 1px solid #fca5a5;
        }
        .skill-chip-neutral {
            background-color: #eff6ff;
            color: #2563eb;
            border: 1px solid #93c5fd;
        }

        .badge {
            display: inline-block;
            padding: 6px 16px;
            border-radius: 999px;
            font-weight: 700;
            font-size: 13px;
        }

        .best-match-banner {
            background: linear-gradient(90deg, #fbbf24, #f59e0b);
            color: white;
            padding: 6px 16px;
            border-radius: 999px;
            font-weight: 700;
            font-size: 13px;
            display: inline-block;
            margin-bottom: 10px;
        }

        .empty-state {
            text-align: center;
            padding: 60px 20px;
            color: #6b7280;
        }

        section[data-testid="stSidebar"] {
            background-color: #111827;
        }
        section[data-testid="stSidebar"] * {
            color: #f3f4f6 !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


# ---------- Skill tags ----------

def render_skill_tags(skills, kind="neutral"):
    """kind: 'matched' | 'missing' | 'neutral'"""
    if not skills:
        st.caption("None")
        return
    css_class = f"skill-chip-{kind}"
    chips_html = "".join(
        f'<span class="skill-chip {css_class}">{s}</span>' for s in skills
    )
    st.markdown(chips_html, unsafe_allow_html=True)


# ---------- Score gauge ----------

def render_score_gauge(score: int, key: str = None):
    color = score_color(score)
    fig = go.Figure(
        go.Indicator(
            mode="gauge+number",
            value=score,
            number={"suffix": " / 100", "font": {"size": 28}},
            gauge={
                "axis": {"range": [0, 100], "tickwidth": 1},
                "bar": {"color": color, "thickness": 0.3},
                "bgcolor": "white",
                "borderwidth": 0,
                "steps": [
                    {"range": [0, 50], "color": "#fee2e2"},
                    {"range": [50, 75], "color": "#fef9c3"},
                    {"range": [75, 100], "color": "#dcfce7"},
                ],
            },
        )
    )
    fig.update_layout(
        height=200,
        margin=dict(l=20, r=20, t=20, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
    )
    st.plotly_chart(fig, use_container_width=True, key=key)


# ---------- Candidate card ----------

def render_candidate_card(result: dict, job_required_skills, is_best_match=False, key_prefix=""):
    score = int(result.get("match_score", 0))
    color = score_color(score)
    badge_color, badge_bg = recommendation_badge_style(result.get("recommendation", ""))

    st.markdown(f'<div class="candidate-card" style="--score-color:{color};">', unsafe_allow_html=True)

    if is_best_match:
        st.markdown('<div class="best-match-banner">🏆 Best Match</div>', unsafe_allow_html=True)

    top_col1, top_col2 = st.columns([2, 1])
    with top_col1:
        st.markdown(f"### {result.get('candidate_name', 'Unknown Candidate')}")
        st.markdown(
            f'<span class="badge" style="background-color:{badge_bg}; color:{badge_color};">'
            f'{result.get("recommendation", "N/A")}</span>',
            unsafe_allow_html=True,
        )
        st.write("")
        st.markdown(f"**Experience:** {result.get('total_experience_years', 'N/A')} years")
        st.markdown(f"**Education:** {result.get('education', 'N/A')}")
    with top_col2:
        render_score_gauge(score, key=f"gauge_{key_prefix}")

    st.markdown("**✅ Matched Skills**")
    render_skill_tags(result.get("matched_skills", []), kind="matched")

    st.markdown("**❌ Missing Skills**")
    render_skill_tags(result.get("missing_skills", []), kind="missing")

    with st.expander("All extracted skills"):
        render_skill_tags(result.get("extracted_skills", []), kind="neutral")

    st.markdown("**Why this score:**")
    st.info(result.get("explanation", "No explanation available."))

    st.markdown("</div>", unsafe_allow_html=True)


# ---------- Empty states ----------

def render_empty_state(icon: str, title: str, subtitle: str):
    st.markdown(
        f"""
        <div class="empty-state">
            <div style="font-size: 48px;">{icon}</div>
            <h3>{title}</h3>
            <p>{subtitle}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


# ---------- Skill input -> chips preview (used on the upload page) ----------

def render_skill_input_preview(raw_skills_text: str):
    skills = [s.strip() for s in raw_skills_text.split(",") if s.strip()]
    if skills:
        render_skill_tags(skills, kind="neutral")
    return skills


def safe_json_list(value):
    """Parse a JSON-encoded list stored in SQLite back into a Python list."""
    if isinstance(value, list):
        return value
    try:
        parsed = json.loads(value)
        return parsed if isinstance(parsed, list) else []
    except (TypeError, json.JSONDecodeError):
        return []
