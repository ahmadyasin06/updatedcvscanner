# AI CV Screening System

A Streamlit app that parses candidate CVs (PDF/DOCX), scores them against a
job posting using the Google Gemini API, and stores results in SQLite for
later review.

## Setup

1. **Create a virtual environment (recommended)**
   ```bash
   python -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   ```

2. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

3. **Add your Gemini API key**
   - Copy `.env.example` to `.env`
   - Get a free key from https://aistudio.google.com/app/apikey
   - Paste it into `.env`:
     ```
     GEMINI_API_KEY=your_actual_key_here
     ```

4. **Run the app**
   ```bash
   streamlit run app.py
   ```

The app will open at `http://localhost:8501`. A `cv_screening.db` SQLite
file is created automatically on first run.

## Project Structure

| File | Purpose |
|---|---|
| `app.py` | Main app, navigation, and all three pages |
| `cv_parser.py` | Extracts text from PDF/DOCX files |
| `ai_analyzer.py` | Builds the Gemini prompt, calls the API, validates JSON |
| `database.py` | SQLite schema + save/fetch functions |
| `ui_components.py` | Styled cards, chips, gauges, empty states |
| `requirements.txt` | Python dependencies |
| `.env.example` | Template for your API key (never commit `.env` itself) |
