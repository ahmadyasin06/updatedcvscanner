"""
ai_analyzer.py
Sends CV text + job requirements to the Gemini API and returns a
validated, structured analysis dict.
"""

import os
import json
import re
import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
MODEL_NAME = "gemini-1.5-flash"  # fast + free-tier friendly

REQUIRED_FIELDS = [
    "candidate_name",
    "total_experience_years",
    "extracted_skills",
    "matched_skills",
    "missing_skills",
    "education",
    "match_score",
    "recommendation",
    "explanation",
]


class GeminiConfigError(Exception):
    """Raised when the API key is missing or invalid."""
    pass


class GeminiAPIError(Exception):
    """Raised when the Gemini API call itself fails (network, quota, etc.)."""
    pass


class MalformedResponseError(Exception):
    """Raised when Gemini's response can't be parsed into valid JSON."""
    pass


def _configure():
    if not GEMINI_API_KEY:
        raise GeminiConfigError(
            "GEMINI_API_KEY is not set. Add it to your .env file "
            "(see .env.example)."
        )
    genai.configure(api_key=GEMINI_API_KEY)


def _build_prompt(cv_text: str, job_info: dict) -> str:
    return f"""
You are an expert technical recruiter and CV screening assistant.

Analyze the CANDIDATE'S CV against the JOB REQUIREMENTS below and return
ONLY a single valid JSON object — no markdown fences, no commentary,
no explanation outside the JSON.

JOB REQUIREMENTS:
- Job Title: {job_info.get('job_title', '')}
- Job Description: {job_info.get('job_description', '')}
- Required Skills: {', '.join(job_info.get('required_skills', []))}
- Experience Required: {job_info.get('experience_required', '')}
- Education Requirement: {job_info.get('education_requirement', '')}

CANDIDATE CV TEXT:
\"\"\"
{cv_text}
\"\"\"

Return a JSON object with EXACTLY these fields:
{{
  "candidate_name": "string - extracted full name, or 'Unknown Candidate' if not found",
  "total_experience_years": "number - total years of professional experience, best estimate",
  "extracted_skills": ["list of all skills/technologies found in the CV"],
  "matched_skills": ["list of required skills that ARE present in the CV"],
  "missing_skills": ["list of required skills that are NOT present in the CV"],
  "education": "string - highest education qualification found",
  "match_score": "integer 0-100 - overall fit for this specific job",
  "recommendation": "one of: 'Strongly Recommended', 'Consider', 'Not Recommended'",
  "explanation": "2-3 sentence explanation of why this score was given"
}}

Scoring guide:
- 75-100 -> Strongly Recommended (strong skills + experience + education match)
- 50-74  -> Consider (partial match, some gaps)
- 0-49   -> Not Recommended (major gaps in skills, experience, or education)

Respond with ONLY the JSON object.
"""


def _strip_code_fences(raw_text: str) -> str:
    """Gemini sometimes wraps JSON in ```json ... ``` fences — strip them."""
    cleaned = raw_text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned)
    return cleaned.strip()


def _validate_and_normalize(data: dict) -> dict:
    for field in REQUIRED_FIELDS:
        if field not in data:
            raise MalformedResponseError(
                f"Gemini response is missing required field: '{field}'"
            )

    # Normalize types defensively
    try:
        data["match_score"] = max(0, min(100, int(float(data["match_score"]))))
    except (ValueError, TypeError):
        data["match_score"] = 0

    try:
        data["total_experience_years"] = float(data["total_experience_years"])
    except (ValueError, TypeError):
        data["total_experience_years"] = 0

    for list_field in ["extracted_skills", "matched_skills", "missing_skills"]:
        if not isinstance(data[list_field], list):
            data[list_field] = []

    if data["recommendation"] not in (
        "Strongly Recommended",
        "Consider",
        "Not Recommended",
    ):
        # Derive recommendation from score if Gemini's label doesn't match
        score = data["match_score"]
        if score >= 75:
            data["recommendation"] = "Strongly Recommended"
        elif score >= 50:
            data["recommendation"] = "Consider"
        else:
            data["recommendation"] = "Not Recommended"

    if not data.get("candidate_name"):
        data["candidate_name"] = "Unknown Candidate"

    return data


def analyze_cv(cv_text: str, job_info: dict) -> dict:
    """
    Main entry point: sends CV text + job info to Gemini and returns a
    validated analysis dict. Raises GeminiConfigError, GeminiAPIError,
    or MalformedResponseError on failure — callers should catch these.
    """
    _configure()
    prompt = _build_prompt(cv_text, job_info)

    try:
        model = genai.GenerativeModel(MODEL_NAME)
        response = model.generate_content(
            prompt,
            generation_config=genai.types.GenerationConfig(
                temperature=0.2,
                response_mime_type="application/json",
            ),
        )
        raw_text = response.text
    except Exception as e:
        raise GeminiAPIError(f"Gemini API call failed: {e}")

    cleaned = _strip_code_fences(raw_text)

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        # Last-resort attempt: pull out the first {...} block
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group(0))
            except json.JSONDecodeError:
                raise MalformedResponseError(
                    "Gemini returned text that could not be parsed as JSON."
                )
        else:
            raise MalformedResponseError(
                "Gemini returned text that could not be parsed as JSON."
            )

    return _validate_and_normalize(data)
